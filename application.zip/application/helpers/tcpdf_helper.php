<?php
defined('BASEPATH') or exit('No direct script access allowed');

function load_tcpdf()
{
    require_once APPPATH . '../vendor/autoload.php';
}
